<?php $__env->startComponent('mail::message'); ?>
# Introduction


For reseting password click to verify and set password
<?php $__env->startComponent('mail::button', ['url' => 'http://localhost:3006/admin-password-reset/'.$token]); ?>
Click to verify
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\austta\server\resources\views/emails/ResetPassword.blade.php ENDPATH**/ ?>