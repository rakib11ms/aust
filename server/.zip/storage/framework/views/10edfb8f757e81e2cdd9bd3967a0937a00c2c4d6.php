<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\austta\server\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>