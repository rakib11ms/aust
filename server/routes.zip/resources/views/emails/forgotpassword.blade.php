@component('mail::message')
# Forgot Password Otp Verification

Below this code is otp for forgot password

# {{ $otp }}

Thanks,<br>
@endcomponent

