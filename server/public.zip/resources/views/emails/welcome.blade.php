@component('mail::message')
# Otp Verification

Below this code is otp for verification

# {{ $otp }}

Thanks,<br>
@endcomponent

