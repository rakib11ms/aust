<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AusttaaBloodGroup extends Model
{
    use HasFactory;
    //   public function bloodGroup()
    // {
    //     return $this->belongsTo('App\Models\User','blood_group');
    // }
}
